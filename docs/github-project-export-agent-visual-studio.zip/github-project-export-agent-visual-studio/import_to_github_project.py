#!/usr/bin/env python3
import csv
import json
import os
import subprocess
import sys
from pathlib import Path

DEFAULT_REPO = os.environ.get("DEFAULT_REPO", "lssmanager/dashboard-agentes")
PROJECT_TITLE = os.environ.get("PROJECT_TITLE", "")
DRY_RUN = os.environ.get("DRY_RUN", "0") == "1"
BASE = Path(__file__).resolve().parent


def run(cmd, input_text=None, check=True):
    print("$", " ".join(cmd))
    if DRY_RUN:
        return ""
    p = subprocess.run(cmd, input=input_text, text=True, capture_output=True)
    if check and p.returncode != 0:
        print(p.stdout)
        print(p.stderr, file=sys.stderr)
        raise SystemExit(p.returncode)
    return p.stdout.strip()


def read_csv(name):
    with open(BASE / name, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def repo_parts(repo):
    owner, name = repo.split("/", 1)
    return owner, name


def ensure_label(repo, row):
    cmd = [
        "gh", "label", "create", row["name"],
        "-R", repo,
        "--description", row["description"][:100],
        "--color", row["color"],
        "--force",
    ]
    run(cmd, check=False)


def milestone_number(repo, title):
    owner, name = repo_parts(repo)
    out = run(["gh", "api", f"repos/{owner}/{name}/milestones", "--paginate"], check=False)
    if not out:
        return None
    try:
        data = json.loads(out)
    except Exception:
        return None
    for m in data:
        if m.get("title") == title:
            return m.get("number")
    return None


def ensure_milestone(repo, row):
    number = milestone_number(repo, row["milestone"])
    if number:
        return number
    owner, name = repo_parts(repo)
    cmd = [
        "gh", "api", f"repos/{owner}/{name}/milestones",
        "-f", f"title={row['milestone']}",
        "-f", f"description={row['description']}",
    ]
    if row.get("due_date"):
        cmd += ["-f", f"due_on={row['due_date']}T23:59:59Z"]
    out = run(cmd)
    try:
        return json.loads(out).get("number")
    except Exception:
        return None


def create_issue(row, issue_map):
    repo = row.get("repo") or DEFAULT_REPO
    labels = [x for x in row["labels"].split(",") if x]
    body = build_body(row, issue_map, resolved=False)
    cmd = [
        "gh", "issue", "create",
        "-R", repo,
        "--title", row["title"],
        "--body", body,
        "--milestone", row["milestone"],
    ]
    for label in labels:
        cmd += ["--label", label]
    if PROJECT_TITLE:
        cmd += ["--project", PROJECT_TITLE]
    url = run(cmd)
    number = url.rstrip("/").split("/")[-1] if url else ""
    return {"repo": repo, "url": url, "number": number}


def dep_refs(row, issue_map):
    refs = []
    current_repo = row.get("repo") or DEFAULT_REPO
    for key in [x.strip() for x in row.get("depends_on_keys", "").split(",") if x.strip()]:
        item = issue_map.get(key)
        if not item:
            refs.append(f"`{key}`")
            continue
        if item["repo"] == current_repo:
            refs.append(f"#{item['number']}")
        else:
            refs.append(f"{item['repo']}#{item['number']}")
    return refs


def build_body(row, issue_map, resolved):
    refs = dep_refs(row, issue_map) if resolved else []
    dep_line = ", ".join(refs) if refs else (row.get("depends_on_keys") or "—")
    return f"""## Objetivo
{row['title']}

## Contexto del Plan Maestro
- Plan key: `{row['issue_key']}`
- Fase: `{row['phase']}` — {row['phase_name']}
- Milestone: `{row['milestone']}`
- Módulo: `{row['module']}`
- Prioridad: `{row['priority']}`
- Área: `{row['area']}`
- Inicio planificado: `{row['start_date']}`
- Fin planificado: `{row['end_date']}`
- Duración: `{row['duration_days']} día(s)`

## Dependencias
- Depends-on: {dep_line}
- Keys originales: `{row.get('depends_on_keys') or '—'}`
- Raw: `{row.get('depends_on_raw') or '—'}`

## Criterio de cierre
Cerrar este issue solo cuando la tarea esté implementada, testeada y enlazada al milestone `{row['milestone']}`.

---
Importado desde `plan-master.md` / `plan-gantt.md`.
"""


def update_issue_body(row, item, issue_map):
    if not item.get("number"):
        return
    body = build_body(row, issue_map, resolved=True)
    run(["gh", "issue", "edit", item["number"], "-R", item["repo"], "--body", body])


def main():
    issues = read_csv("github_issues_import.csv")
    labels = read_csv("github_labels.csv")
    milestones = read_csv("github_milestones.csv")
    repos = sorted(set([(r.get("repo") or DEFAULT_REPO) for r in issues]))

    print(f"Repos destino: {', '.join(repos)}")
    print(f"Project: {PROJECT_TITLE or '(sin --project; solo se crean issues)'}")

    for repo in repos:
        for label in labels:
            ensure_label(repo, label)
        for milestone in milestones:
            ensure_milestone(repo, milestone)

    issue_map = {}
    for row in issues:
        item = create_issue(row, issue_map)
        issue_map[row["issue_key"]] = item
        (BASE / "created_issues.json").write_text(json.dumps(issue_map, indent=2, ensure_ascii=False), encoding="utf-8")

    for row in issues:
        update_issue_body(row, issue_map[row["issue_key"]], issue_map)

    print("Importación completada.")
    print(f"Mapa creado: {BASE / 'created_issues.json'}")


if __name__ == "__main__":
    main()
