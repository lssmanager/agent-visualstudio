# Export GitHub Projects — Agent Visual Studio

Este paquete convierte `plan-master.md` y `plan-gantt.md` en una carga lista para GitHub Issues + GitHub Projects.

## Archivos

- `github_issues_import.csv`: 94 issues generados desde el Plan Maestro.
- `github_milestones.csv`: 11 milestones, uno por fase.
- `github_labels.csv`: 21 labels técnicos (`phase:*`, `priority:*`, `area:*`).
- `github_project_fields.csv`: campos recomendados para el tablero GitHub Projects.
- `import_to_github_project.py`: script que crea labels, milestones, issues y agrega los issues al Project si defines `PROJECT_TITLE`.

## Antes de correr

Instala y autentica GitHub CLI:

```bash
gh auth login
gh auth refresh -s project
```

Crea el Project en GitHub:

```text
GitHub → lssmanager → Projects → New project → Board
```

Nombre sugerido:

```text
Agent Visual Studio Roadmap
```

## Importación recomendada

Desde esta carpeta:

```bash
cd github-project-export-agent-visual-studio
export PROJECT_TITLE="Agent Visual Studio Roadmap"
export DEFAULT_REPO="lssmanager/dashboard-agentes"
python import_to_github_project.py
```

Modo prueba, sin crear nada:

```bash
DRY_RUN=1 PROJECT_TITLE="Agent Visual Studio Roadmap" python import_to_github_project.py
```

## Nota importante

GitHub Projects no importa CSV directamente como tablero completo. El método limpio es:

1. Crear labels.
2. Crear milestones.
3. Crear issues desde el CSV.
4. Agregar cada issue al Project con `--project`.
5. Usar labels/milestones/campos para vistas del tablero.

## Vistas recomendadas del Project

- Board por `Status`.
- Table agrupada por `Milestone`.
- Board filtrado por `priority:blocker`.
- Table filtrada por `area:frontend` / `area:backend` / `area:infra`.
- Roadmap por milestone y fecha.
